<div class="v3d-order-form">
  <?= esc_html(get_option('v3d_order_success_text')); ?>
</div>
