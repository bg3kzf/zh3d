<div class="v3d-order-form">
  <?= esc_html(get_option('v3d_order_failed_text')); ?>
</div>
